import React,{Component} from "react";
import data from "./data/city.list.json";
import {FetchData} from "./Components/FetchData";


export default class App extends Component{
    constructor(props) {
        super(props);
        this.state = {
            getData: false,
        }
    }

    CountryData = (data)=>{
        return(
            <div>
                {data.map((items, index)=>{
                   return  items.name === 'Chambarak' ?
                        JSON.stringify(items) : ''
                })}
            </div>
        )
    }
    GetData = ()=>{
        this.setState(prevState=>{
            let{getData} = prevState
            return {getData: !getData}
        })
    }


    render() {
        let{getData} = this.state
        // alert(JSON.stringify(items.list))
        // alert(JSON.stringify(arr_of_date))
        return (
            <div>
                <FetchData/>
                <button onClick={()=>this.GetData()}>Get Country Data</button>
                {getData ? this.CountryData(data) : null}
            </div>
        )
    }
}