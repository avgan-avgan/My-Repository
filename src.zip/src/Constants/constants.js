export const City = 'Chambarak'
export const StateCode = '616786'
export const CountryCode = 'am'
export const MyAPIKey = '3f4eb6b9410ca7321e7b9e89d569d368'
/******************Language codes***********/
export const English = 'en'
export const Russian = 'ru'
export const Germany = 'de'